# 💌 Credits
The content in this loadBlockquotes folder is credits to the [Quote Colors & Collapse Extension](https://addons.thunderbird.net/en-US/thunderbird/addon/quotecolors/) by [Alexander Ihrig](https://addons.thunderbird.net/en-Us/thunderbird/user/AlexanderIhrig/)!

I just changed the colors, measurements, removed the extension's options, and removed the collapse function.

Thank you so much for sharing your talent! 